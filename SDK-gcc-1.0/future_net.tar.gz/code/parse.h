#ifndef _PARSE_
#define _PARSE_
#include "graph.h"
Edge * parse2edge(char * line);
int parse2demand(char * demand,int * demandTo, int * s, int * t);

#endif
